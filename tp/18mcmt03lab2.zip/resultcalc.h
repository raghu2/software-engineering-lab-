#include<stdio.h>
#include<stdlib.h>

float avgresult(int a,int b){
	float c=(a+b)/2;
	return c;
}
